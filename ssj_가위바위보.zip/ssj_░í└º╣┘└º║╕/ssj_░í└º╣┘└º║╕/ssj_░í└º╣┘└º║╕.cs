﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ssj_가위바위보
{
    public partial class ssj_가위바위보 : Form
    {
        public ssj_가위바위보()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pb2.ImageLocation = "file: ///C:/debug/Images/gawei.jpg";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pb2.ImageLocation = "Images/bawei.jpg";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pb2.ImageLocation = "Images/bo.jpg";
        }
    }
}
